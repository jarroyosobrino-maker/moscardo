# Calendario CDC Moscardó — datos en GitHub

La idea: **el código se pega en Wix UNA sola vez y nunca más**. Ese código pide los datos
a `datos.json`, alojado aquí en GitHub, cada vez que alguien abre la página. Para actualizar
la web solo hay que cambiar `datos.json`; Wix no se toca.

## Puesta en marcha (una sola vez, unos 10 minutos)

1. **Crea el repositorio.** En github.com → New repository → nombre `moscardo-web`,
   marca **Public** y créalo. Sube estos tres ficheros (`datos.json`, `index.html`, `wix.html`)
   arrastrándolos a la página del repositorio y pulsa *Commit changes*.

2. **Activa GitHub Pages.** En el repositorio → *Settings* → *Pages* →
   en *Source* elige `Deploy from a branch`, rama `main`, carpeta `/ (root)` → *Save*.
   A los 2-3 minutos tendrás una dirección así:

       https://TU-USUARIO.github.io/moscardo-web/

   Ábrela: debe verse el calendario entero. Esa es la prueba de que todo funciona.

3. **Prepara el código de Wix.** Abre `wix.html`, busca esta línea (está casi al final):

       const ORIGEN = "__PON_AQUI_LA_URL_DE_TU_DATOS_JSON__";

   y sustituye ese texto por la dirección de tu `datos.json`, que será:

       https://TU-USUARIO.github.io/moscardo-web/datos.json

4. **Pega en Wix.** En el elemento de código HTML de la página Calendario / Resultados,
   borra lo que haya y pega el contenido completo de `wix.html` ya editado. Publica.
   Altura del elemento: unos **3900 px** en escritorio y **4900** en móvil.

A partir de aquí, Wix queda congelado para siempre.

## Cada semana

Claude te enviará un `datos.json` nuevo. Para publicarlo tienes dos formas:

**Desde el navegador** (lo más simple): entra al fichero `datos.json` en GitHub,
pulsa el lápiz de editar, pega el contenido nuevo encima y *Commit changes*.
En un par de minutos la web del club ya lo muestra.

**Desde el ordenador**, si tienes git instalado: guarda el `datos.json` nuevo en la
carpeta del repositorio y ejecuta

    python publicar.py

## Qué hay en cada fichero

- `datos.json` — lo único que cambia: partidos, resultados, horarios y clasificación.
- `wix.html` — el código que se pega en Wix. Solo se toca si cambia el diseño.
- `index.html` — la misma página, para verla en GitHub Pages y comprobar los datos.
- `publicar.py` — atajo para subir `datos.json` con git.

## Un detalle sobre el caché

GitHub Pages guarda copia unos minutos. El código ya pide el fichero con una marca de
tiempo para saltárselo, pero si acabas de cambiarlo y aún ves lo viejo, espera cinco
minutos antes de preocuparte.
