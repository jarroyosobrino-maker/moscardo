#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sube datos.json al repositorio. Ejecutar desde la carpeta del repositorio."""
import json, subprocess, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
datos = BASE / "datos.json"

if not datos.exists():
    sys.exit("No encuentro datos.json en esta carpeta.")

try:
    d = json.loads(datos.read_text(encoding="utf-8"))
except json.JSONDecodeError as e:
    sys.exit(f"datos.json no es JSON válido ({e}). No subo nada para no romper la web.")

for clave in ("partidos", "clasificacion"):
    if not d.get(clave):
        sys.exit(f'datos.json no tiene "{clave}". No subo nada.')

jugados = sum(1 for p in d["partidos"] if isinstance(p.get("gf"), int))
mensaje = f'Actualiza datos ({jugados} jornadas disputadas)'

def git(*args):
    r = subprocess.run(["git", *args], cwd=BASE, capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"git {' '.join(args)} falló:\n{r.stderr.strip()}")
    return r.stdout.strip()

if not git("status", "--porcelain", "datos.json"):
    print("datos.json no ha cambiado. No hay nada que subir.")
    sys.exit(0)

git("add", "datos.json")
git("commit", "-m", mensaje)
git("push")
print(f"Subido: {mensaje}. En unos minutos estará en la web.")
